### Hexlet tests and linter status:
[![Actions Status](https://github.com/mzubkov-artenecy/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/mzubkov-artenecy/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/b3bad4481441392bdf99/maintainability)](https://codeclimate.com/github/mzubkov-artenecy/python-project-49/maintainability)

[Video for BRAIN-EVEN task](https://disk.yandex.ru/i/dr6t8I0d56d5fg)

[Video for BRAIN-CALC task](https://disk.yandex.ru/i/MtZatESZVJCcJw)
